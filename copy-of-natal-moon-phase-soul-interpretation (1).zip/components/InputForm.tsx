import React, { useState, useEffect } from 'react';
import { CITY_DB } from '../constants';
import { FormData } from '../types';
import { MapPin, Calendar, Clock, Sun } from 'lucide-react';

interface InputFormProps {
  onCalculate: (data: FormData) => void;
}

const InputForm: React.FC<InputFormProps> = ({ onCalculate }) => {
  const [formData, setFormData] = useState<FormData>({
    birthDate: '1995-06-15',
    birthTime: '14:30',
    province: '',
    city: '',
    isDST: false,
  });

  const [availableCities, setAvailableCities] = useState<any[]>([]);

  useEffect(() => {
    if (formData.province && CITY_DB[formData.province]) {
      setAvailableCities(CITY_DB[formData.province]);
      // Reset city when province changes
      setFormData(prev => ({ ...prev, city: '' }));
    } else {
      setAvailableCities([]);
    }
  }, [formData.province]);

  // Set default city when available cities update and none selected
  useEffect(() => {
      if (availableCities.length > 0 && !formData.city) {
          setFormData(prev => ({ ...prev, city: JSON.stringify(availableCities[0]) }));
      }
  }, [availableCities, formData.city]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.city) {
        alert("请选择城市 Please select a city");
        return;
    }
    onCalculate(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl mx-auto bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl mb-16">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        
        {/* Date */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-slate-400 font-bold text-sm tracking-wider uppercase">
            <Calendar size={16} className="text-purple-500"/> 出生日期 (Date)
          </label>
          <input
            type="date"
            required
            value={formData.birthDate}
            onChange={e => setFormData({ ...formData, birthDate: e.target.value })}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors"
          />
        </div>

        {/* Time */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-slate-400 font-bold text-sm tracking-wider uppercase">
            <Clock size={16} className="text-purple-500"/> 出生时间 (Time)
          </label>
          <input
            type="time"
            required
            value={formData.birthTime}
            onChange={e => setFormData({ ...formData, birthTime: e.target.value })}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors"
          />
          <p className="text-xs text-slate-600 pl-1">Input local time of birth</p>
        </div>

        {/* Province */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-slate-400 font-bold text-sm tracking-wider uppercase">
            <MapPin size={16} className="text-purple-500"/> 省份 (Province)
          </label>
          <select
            value={formData.province}
            onChange={e => setFormData({ ...formData, province: e.target.value })}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors appearance-none cursor-pointer"
          >
            <option value="">-- Select Province --</option>
            {Object.keys(CITY_DB).map(prov => (
              <option key={prov} value={prov}>{prov}</option>
            ))}
          </select>
        </div>

        {/* City */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-slate-400 font-bold text-sm tracking-wider uppercase">
            <MapPin size={16} className="text-purple-500"/> 城市 (City)
          </label>
          <select
            value={formData.city}
            onChange={e => setFormData({ ...formData, city: e.target.value })}
            disabled={!formData.province}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 transition-colors appearance-none cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
             {!formData.province ? <option>Select province first</option> : null}
             {availableCities.map((c, idx) => (
               <option key={idx} value={JSON.stringify(c)}>{c.name}</option>
             ))}
          </select>
        </div>
      </div>

      {/* DST Toggle */}
      <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 flex items-center justify-between mb-8">
         <div className="flex items-center gap-3">
             <div className="bg-amber-500/20 p-2 rounded-lg text-amber-500">
                 <Sun size={20} />
             </div>
             <div>
                 <h4 className="font-bold text-amber-400 text-sm">夏令时调整 (Daylight Saving)</h4>
                 <p className="text-xs text-amber-200/60 mt-0.5">Check if birth was during DST (usually +1h)</p>
             </div>
         </div>
         <label className="relative inline-flex items-center cursor-pointer">
            <input 
                type="checkbox" 
                checked={formData.isDST} 
                onChange={e => setFormData({...formData, isDST: e.target.checked})}
                className="sr-only peer" 
            />
            <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-500"></div>
        </label>
      </div>

      <button
        type="submit"
        className="w-full py-4 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-lg rounded-xl shadow-lg shadow-purple-900/50 transition-all transform hover:-translate-y-1 active:translate-y-0 tracking-widest uppercase"
      >
        🔮 开始精确解读 (Calculate)
      </button>
    </form>
  );
};

export default InputForm;