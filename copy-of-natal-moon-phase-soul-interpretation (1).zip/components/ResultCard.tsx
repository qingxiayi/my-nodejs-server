
import React, { useRef, useState } from 'react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { CalculationResult } from '../types';
import { Download, FileText, Sun, Moon, MapPin, Clock, Compass, X, ArrowUp, ArrowDown, Save } from 'lucide-react';

interface ResultCardProps {
  data: CalculationResult | null;
}

const ResultCard: React.FC<ResultCardProps> = ({ data }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  if (!data) return null;

  const handleGenerateImage = async () => {
    if (cardRef.current) {
      setIsGenerating(true);
      try {
        // Wait for images/fonts to be ready
        await new Promise(resolve => setTimeout(resolve, 100));
        
        const canvas = await html2canvas(cardRef.current, {
          backgroundColor: '#0f172a', // Slate 900
          scale: 2,
          useCORS: true,
          logging: false,
        });
        
        const imgData = canvas.toDataURL('image/png');
        
        // Show modal instead of auto-download for WeChat compatibility
        setGeneratedImage(imgData);
      } catch (error) {
        console.error("Image generation failed", error);
        alert("图片生成失败，请重试");
      } finally {
        setIsGenerating(false);
      }
    }
  };

  const handleDirectDownload = () => {
      if (generatedImage) {
          const link = document.createElement('a');
          link.href = generatedImage;
          link.download = `MoonPhase_${data.birthDateStr}.png`;
          link.click();
      }
  }

  const handleDownloadPDF = async () => {
    if (cardRef.current) {
        setIsGenerating(true);
        try {
            const canvas = await html2canvas(cardRef.current, {
                scale: 2,
                backgroundColor: '#0f172a'
            });
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF({
                orientation: 'portrait',
                unit: 'px',
                format: [canvas.width, canvas.height]
            });
            pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
            pdf.save(`MoonPhase_${data.birthDateStr}.pdf`);
        } catch (error) {
            console.error("PDF generation failed", error);
            alert("PDF生成失败");
        } finally {
            setIsGenerating(false);
        }
    }
  };

  const { phase, isDayBirth, angle, sunAltitude } = data;
  const isWaxing = phase.hemicycle === 'waxing';

  return (
    <div className="w-full max-w-4xl mx-auto animate-fade-in pb-20">
      {/* Action Buttons */}
      <div className="flex flex-wrap gap-4 mb-8 justify-center">
        <button
          onClick={handleGenerateImage}
          disabled={isGenerating}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl font-bold text-slate-900 hover:shadow-lg hover:shadow-amber-500/20 transition-all hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download size={20} />
          {isGenerating ? '生成中...' : '生成图片 (Generate Image)'}
        </button>
        <button
          onClick={handleDownloadPDF}
          disabled={isGenerating}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-pink-500 to-rose-500 rounded-xl font-bold text-white hover:shadow-lg hover:shadow-pink-500/20 transition-all hover:-translate-y-1 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <FileText size={20} />
          {isGenerating ? '生成中...' : '下载为PDF'}
        </button>
      </div>

      {/* Image Preview Modal (For WeChat/Mobile) */}
      {generatedImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4 backdrop-blur-md animate-fade-in" onClick={() => setGeneratedImage(null)}>
          <div className="relative max-w-full max-h-full flex flex-col items-center" onClick={e => e.stopPropagation()}>
             <div className="bg-slate-900 rounded-xl p-2 mb-4 shadow-2xl overflow-hidden max-h-[70vh] overflow-y-auto border border-slate-700">
                <img src={generatedImage} alt="Generated Result" className="w-full h-auto object-contain" />
             </div>
             
             <div className="flex flex-col items-center gap-3">
                <p className="text-amber-300 text-base font-bold drop-shadow-md text-center">
                    👆 手机：长按图片保存到相册<br/>(Mobile: Long press to save)
                </p>
                <div className="flex gap-3">
                    <button 
                        onClick={handleDirectDownload}
                        className="flex items-center gap-2 px-6 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-full transition-colors font-bold"
                    >
                        <Save size={18} /> 电脑：直接下载 (Desktop Download)
                    </button>
                    <button 
                        onClick={() => setGeneratedImage(null)}
                        className="flex items-center gap-2 px-6 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-full transition-colors"
                    >
                        <X size={18} /> 关闭 (Close)
                    </button>
                </div>
             </div>
          </div>
        </div>
      )}

      {/* Main Card */}
      <div
        ref={cardRef}
        className="bg-slate-900 border border-slate-800 rounded-3xl p-8 md:p-12 shadow-2xl relative overflow-hidden text-slate-200"
      >
        {/* Background Decorative Elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

        {/* Header Section */}
        <div className="relative z-10 border-b border-slate-700/50 pb-8 mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-6">
            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border ${isDayBirth ? 'bg-amber-500/10 border-amber-500/50 text-amber-400' : 'bg-purple-500/10 border-purple-500/50 text-purple-400'}`}>
              {isDayBirth ? <Sun size={18} /> : <Moon size={18} />}
              <span className="font-bold tracking-wide uppercase text-sm">
                {isDayBirth ? '日生盘 (Day Chart)' : '夜生盘 (Night Chart)'}
              </span>
            </div>
            <div className="text-slate-400 text-sm font-mono flex flex-wrap gap-4">
               <span className="flex items-center gap-1"><Clock size={14}/> {data.birthDateStr} {data.birthTimeStr}</span>
               <span className="flex items-center gap-1"><MapPin size={14}/> {data.locationName}</span>
               <span className="flex items-center gap-1"><Compass size={14}/> UTC{data.timezone > 0 ? '+' : ''}{data.timezone}</span>
            </div>
          </div>

          <h2 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-amber-200 to-purple-200 mb-2 bg-slate-200">
            {phase.name}
          </h2>
          <p className="text-xl text-purple-300 font-serif italic mb-6">{phase.archetype}</p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-700/50">
                <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">日月夹角 (Angle)</div>
                <div className="text-lg font-bold text-slate-200">{angle.toFixed(1)}°</div>
             </div>
             <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-700/50">
                <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">太阳高度 (Altitude)</div>
                <div className="text-lg font-bold text-slate-200 flex items-center gap-1">
                  {sunAltitude > 0 ? <ArrowUp size={16} className="text-amber-500"/> : <ArrowDown size={16} className="text-purple-500"/>}
                  {Math.abs(sunAltitude).toFixed(1)}°
                </div>
                <div className="text-[10px] text-slate-500 mt-1">
                  {sunAltitude > 0 ? '地平线上 (Day)' : '地平线下 (Night)'}
                </div>
             </div>
             <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-700/50 col-span-2">
                <div className="text-xs text-slate-400 uppercase tracking-wider mb-1">生命周期 (Hemicycle)</div>
                <div className={`text-lg font-bold ${isWaxing ? 'text-amber-400' : 'text-purple-400'}`}>
                    {phase.hemicycleName}
                </div>
             </div>
          </div>
        </div>

        {/* Content Section */}
        <div className="space-y-10 relative z-10">
            
            {/* Rudhyar Core */}
            <section>
                <div className="flex items-center gap-3 mb-4">
                    <div className="w-1 h-8 bg-gradient-to-b from-purple-400 to-purple-600 rounded-full" />
                    <h3 className="text-xl font-bold text-slate-100">Rudhyar 核心原意</h3>
                </div>
                <div className="bg-purple-900/10 border-l-4 border-purple-500/30 p-6 rounded-r-xl text-slate-300 leading-relaxed text-lg">
                    {phase.rudhyarCore}
                </div>
            </section>

            {/* Day/Night Specific */}
            <section>
                <div className="flex items-center gap-3 mb-4">
                    <div className={`w-1 h-8 rounded-full bg-gradient-to-b ${isDayBirth ? 'from-amber-400 to-orange-500' : 'from-indigo-400 to-purple-500'}`} />
                    <h3 className={`text-xl font-bold ${isDayBirth ? 'text-amber-200' : 'text-indigo-200'}`}>
                        {isDayBirth ? '☀️ 日生盘心理视角 (Solar/Ego)' : '🌙 夜生盘心理视角 (Lunar/Psyche)'}
                    </h3>
                </div>
                <div className={`p-6 rounded-xl border border-opacity-20 leading-relaxed text-lg shadow-inner ${isDayBirth ? 'bg-amber-900/10 border-amber-500 text-amber-100/90' : 'bg-indigo-900/10 border-indigo-500 text-indigo-100/90'}`}>
                    {isDayBirth ? phase.dayPhase : phase.nightPhase}
                </div>
            </section>

             {/* Hemicycle */}
             <section>
                <div className="flex items-center gap-3 mb-4">
                    <div className="w-1 h-8 bg-gradient-to-b from-teal-400 to-emerald-600 rounded-full" />
                    <h3 className="text-xl font-bold text-slate-100">您的月相周期位置</h3>
                </div>
                <div className="bg-slate-800/50 p-6 rounded-xl border border-slate-700 text-slate-300 leading-relaxed">
                    <h4 className={`font-bold mb-2 ${isWaxing ? 'text-amber-400' : 'text-purple-400'}`}>{phase.hemicycleName}</h4>
                    {phase.hemicycleDescription}
                </div>
            </section>

            {/* Evolution Path */}
            <section>
                <div className="flex items-center gap-3 mb-4">
                    <div className="w-1 h-8 bg-gradient-to-b from-pink-400 to-rose-600 rounded-full" />
                    <h3 className="text-xl font-bold text-slate-100">灵性进化路径</h3>
                </div>
                <div className="bg-gradient-to-r from-slate-800 to-slate-800/50 p-6 rounded-xl border-l-4 border-pink-500 text-slate-300 leading-relaxed text-lg italic">
                    {phase.evolutionPath}
                </div>
            </section>

            {/* Quote */}
            <div className="mt-12 relative pt-10">
                <span className="absolute top-0 left-4 text-6xl text-amber-500/20 font-serif">"</span>
                <p className="text-center text-xl md:text-2xl text-amber-100/80 font-serif italic px-8">
                    {phase.quote}
                </p>
                <div className="text-center mt-4 text-amber-500/50 text-sm font-bold tracking-widest uppercase">Dane Rudhyar</div>
            </div>

        </div>

        {/* Footer in Image */}
        <div className="mt-12 pt-6 border-t border-slate-800 flex justify-between items-center text-slate-500 text-xs uppercase tracking-widest">
             <span>Natal Moon Phase Soul Interpretation</span>
             <span>Humanistic & Psychological Astrology</span>
        </div>
      </div>
    </div>
  );
};

export default ResultCard;
