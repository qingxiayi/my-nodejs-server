import { City, CalculationResult, MoonPhaseData } from '../types';
import { MOON_PHASES } from '../constants';

// Math helpers
const RAD = Math.PI / 180;
const DEG = 180 / Math.PI;

function sin(deg: number) { return Math.sin(deg * RAD); }
function cos(deg: number) { return Math.cos(deg * RAD); }
// function tan(deg: number) { return Math.tan(deg * RAD); } // Unused
function asin(x: number) { return Math.asin(x) * DEG; }
// function acos(x: number) { return Math.acos(x) * DEG; } // Unused
// function atan2(y: number, x: number) { return Math.atan2(y, x) * DEG; } // Unused

// Normalize angle to 0-360
function normalize360(angle: number): number {
  let res = angle % 360;
  if (res < 0) res += 360;
  return res;
}

export function calculateAstrology(
  dateStr: string,
  timeStr: string,
  city: City,
  isDST: boolean
): CalculationResult {
  // Parse input
  const [year, month, day] = dateStr.split('-').map(Number);
  const [hour, minute] = timeStr.split(':').map(Number);

  // Construct Date object in UTC
  // We need to handle timezone manually to get precise UT
  // Local Time = UT + Offset
  // UT = Local Time - Offset
  // Offset includes DST if active.
  
  // Standard TZ offset for city (e.g. 8 for China)
  let offset = city.tz;
  if (isDST) offset += 1;

  // Convert local time to decimal hours (UT)
  let decimalLocalHours = hour + minute / 60.0;
  let decimalUT = decimalLocalHours - offset;

  // Calculate JD
  // Simplified Julian Date calculation
  let calcYear = year;
  let calcMonth = month;
  let calcDay = day;

  if (calcMonth <= 2) {
    calcYear -= 1;
    calcMonth += 12;
  }

  // Adjust for negative UT or UT > 24 (simple day shift)
  // For rigorous JD, we pass the decimal UT directly into the day fraction
  // But we must ensure the day is correct relative to the UT
  if (decimalUT < 0) {
      calcDay -= 1;
      decimalUT += 24;
  } else if (decimalUT >= 24) {
      calcDay += 1;
      decimalUT -= 24;
  }
  
  const A = Math.floor(calcYear / 100);
  const B = 2 - A + Math.floor(A / 4);
  const JD = Math.floor(365.25 * (calcYear + 4716)) + Math.floor(30.6001 * (calcMonth + 1)) + calcDay + B - 1524.5 + (decimalUT / 24.0);

  // Century T
  const T = (JD - 2451545.0) / 36525.0;

  // --- Sun Position (Meeus simplified) ---
  const L0 = normalize360(280.46646 + 36000.76983 * T + 0.0003032 * T * T);
  const M = normalize360(357.52911 + 35999.05029 * T - 0.0001536 * T * T * T);
  const C = (1.914602 - 0.004817 * T - 0.000014 * T * T) * sin(M) +
            (0.019993 - 0.000101 * T) * sin(2 * M) +
            0.000029 * sin(3 * M);
  const sunTrueLong = normalize360(L0 + C);
  
  // Obliquity of Ecliptic (approx)
  const epsilon = 23.439 - 0.0000004 * (JD - 2451545.0); 
  
  // Sun Declination for Altitude
  const sunDeclination = asin(sin(epsilon) * sin(sunTrueLong));
  
  // Calculate Sun Hour Angle for Day/Night distinction
  // Sidereal Time at Greenwich
  const GMST0 = 280.46061837 + 360.98564736629 * (JD - 2451545.0);
  const GMST = normalize360(GMST0); // This is GMST at 0h UT? No, formula above needs adjustment if T is based on full JD.
  // Actually, simpler GMST formula relative to JD:
  // We need to be careful. Let's use a rougher but safer LST for Day/Night check which doesn't need arc-second precision.
  // Sun's Hour Angle = LST - Sun RA.
  // Sun RA is approx Sun Longitude (projected).
  // Actually, HA = Local Solar Time. 
  // Let's compute Local Solar Time directly from UT + Longitude + EOT.
  // EOT is (Mean Long - True Long) roughly.
  // Hour Angle = (Local Time - 12) * 15 is "civil" approximation, but we have lat/long.
  
  // Let's stick to the geometric method:
  // GMST roughly:
  const UT = decimalUT; 
  // LST (deg) = 15 * UT + Longitude + (GMST at 0h correction).
  // Let's use the actual Sun RA.
  const y = cos(epsilon) * sin(sunTrueLong);
  const x = cos(sunTrueLong);
  const sunRA = normalize360(Math.atan2(y, x) * DEG);
  
  // GMST in degrees
  // GMST = 100.46 + 0.985647 * d + 15 * UT
  const d = JD - 2451545.0;
  const gmstDeg = normalize360(280.4606 + 360.98564736 * T); // This T includes the time fraction? Yes.
  
  const LST = normalize360(gmstDeg + city.lng);
  const hourAngle = normalize360(LST - sunRA);
  
  // Sun Altitude
  // sin(h) = sin(lat)sin(dec) + cos(lat)cos(dec)cos(HA)
  const sinAlt = sin(city.lat) * sin(sunDeclination) + cos(city.lat) * cos(sunDeclination) * cos(hourAngle);
  const sunAltitude = asin(sinAlt);
  // Standard geometric sunset is -0.833 deg (radius + refraction).
  const isDayBirth = sunAltitude >= -0.833; 

  // --- Moon Position (Meeus simplified with major corrections) ---
  const L_moon = normalize360(218.316 + 13.176396 * d); // Mean Longitude
  const M_moon = normalize360(134.963 + 13.064993 * d); // Mean Anomaly
  const F_moon = normalize360(93.272 + 13.229350 * d);  // Argument of Latitude
  
  // Major perturbations
  const moonTrueLong = normalize360(L_moon + 6.289 * sin(M_moon)); 
  // Note: There are many more terms (Evection, Variation, etc.), but for Phase (Sun-Moon angle), 
  // the relative error cancels out partially, but 6deg is the big one. 
  // Adding 'Variation' (0.658 * sin(2 * (L_moon - sunTrueLong))) helps for phases.
  // Let's add specific Phase correction.
  
  // Refined calculation using elongation D
  const D = normalize360(297.850 + 12.190749 * d); // Mean Elongation
  
  const moonLongCorrected = normalize360(
      L_moon 
      + 6.289 * sin(M_moon)              // Equation of Center
      - 1.274 * sin(M_moon - 2 * D)      // Evection
      + 0.658 * sin(2 * D)               // Variation
      - 0.185 * sin(M)                   // Annual Equation
      - 0.114 * sin(2 * F_moon)
  );

  // --- Phase Calculation ---
  let angle = normalize360(moonLongCorrected - sunTrueLong);
  
  // Find phase
  const phase = MOON_PHASES.find(p => angle >= p.degreeRange[0] && angle < p.degreeRange[1]) || MOON_PHASES[0];

  return {
    phase,
    angle,
    sunLng: sunTrueLong,
    moonLng: moonLongCorrected,
    isDayBirth,
    sunAltitude,
    birthDateStr: dateStr,
    birthTimeStr: timeStr,
    locationName: city.name,
    timezone: city.tz,
    isDST
  };
}