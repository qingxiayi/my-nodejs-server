import React, { useState } from 'react';
import InputForm from './components/InputForm';
import ResultCard from './components/ResultCard';
import { CalculationResult, FormData, City } from './types';
import { calculateAstrology } from './services/astrologyService';
import { Moon, Star } from 'lucide-react';

const App: React.FC = () => {
  const [result, setResult] = useState<CalculationResult | null>(null);

  const handleCalculate = (data: FormData) => {
    try {
      const city: City = JSON.parse(data.city);
      const res = calculateAstrology(data.birthDate, data.birthTime, city, data.isDST);
      setResult(res);
      // Smooth scroll to result
      setTimeout(() => {
        const element = document.getElementById('result-section');
        if (element) element.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (e) {
      console.error(e);
      alert("Error parsing city data");
    }
  };

  return (
    <div className="min-h-screen text-slate-200 pb-20 px-4 md:px-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-[#0a0e27] to-[#050510]">
      
      {/* Background Stars (simple CSS effect) */}
      <div className="fixed inset-0 pointer-events-none opacity-40" style={{backgroundImage: 'radial-gradient(white 1px, transparent 1px)', backgroundSize: '50px 50px'}}></div>

      {/* Hero Header */}
      <header className="pt-20 pb-12 text-center relative z-10">
        <div className="inline-flex items-center justify-center p-3 mb-6 bg-purple-500/10 rounded-full border border-purple-500/30 backdrop-blur-sm">
           <Moon className="text-purple-400 mr-2" size={20} />
           <span className="text-purple-200 font-bold text-sm tracking-wider uppercase">Dane Rudhyar Astrology</span>
        </div>
        <h1 className="text-5xl md:text-6xl font-black mb-6 tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-amber-200 via-purple-200 to-indigo-200 drop-shadow-[0_0_15px_rgba(168,85,247,0.5)]">
          本命月相灵魂解读
        </h1>
        <p className="text-lg md:text-xl text-slate-400 max-w-2xl mx-auto font-serif italic">
          "Unveiling the Soul's Purpose through the Lunation Cycle"
        </p>
        <div className="mt-4 flex items-center justify-center gap-2 text-xs text-slate-500 uppercase tracking-widest">
            <Star size={12}/>
            <span>Automatic Day/Night Chart Calculation</span>
            <Star size={12}/>
        </div>
      </header>

      {/* Main Container */}
      <main className="container mx-auto relative z-10">
        <InputForm onCalculate={handleCalculate} />
        
        <div id="result-section">
            <ResultCard data={result} />
        </div>
      </main>
      
      {/* Footer */}
      <footer className="text-center text-slate-600 text-sm pb-8 relative z-10">
        <p>© {new Date().getFullYear()} Soul Moon Phase Calculator. Based on Humanistic Astrology.</p>
      </footer>
    </div>
  );
};

export default App;