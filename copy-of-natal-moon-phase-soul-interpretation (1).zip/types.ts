export interface City {
  name: string;
  lng: number;
  lat: number;
  tz: number; // Timezone offset from UTC (e.g., 8 for UTC+8)
}

export interface CityDatabase {
  [province: string]: City[];
}

export type BirthType = 'day' | 'night';
export type HemicycleType = 'waxing' | 'waning';

export interface MoonPhaseData {
  num: number;
  name: string;
  degreeRange: [number, number]; // [min, max]
  archetype: string;
  hemicycle: HemicycleType;
  hemicycleName: string;
  rudhyarCore: string;
  dayPhase: string;
  nightPhase: string;
  hemicycleDescription: string;
  evolutionPath: string;
  quote: string;
}

export interface CalculationResult {
  phase: MoonPhaseData;
  angle: number;
  sunLng: number;
  moonLng: number;
  isDayBirth: boolean;
  sunAltitude: number; // calculated altitude of sun
  birthDateStr: string;
  birthTimeStr: string;
  locationName: string;
  timezone: number;
  isDST: boolean;
}

export interface FormData {
  birthDate: string;
  birthTime: string;
  province: string;
  city: string; // JSON string of City object
  isDST: boolean;
}