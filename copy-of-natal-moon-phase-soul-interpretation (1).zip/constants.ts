
import { CityDatabase, MoonPhaseData } from './types';

export const CITY_DB: CityDatabase = {
  "北京": [{ name: "北京", lng: 116.4074, lat: 39.9042, tz: 8 }],
  "上海": [{ name: "上海", lng: 121.4737, lat: 31.2304, tz: 8 }],
  "天津": [{ name: "天津", lng: 117.2008, lat: 39.0840, tz: 8 }],
  "重庆": [{ name: "重庆", lng: 106.5516, lat: 29.5630, tz: 8 }],
  "黑龙江": [
    { name: "哈尔滨", lng: 126.5349, lat: 45.8038, tz: 8 },
    { name: "齐齐哈尔", lng: 123.9181, lat: 47.3543, tz: 8 },
    { name: "牡丹江", lng: 129.6331, lat: 44.5516, tz: 8 },
    { name: "佳木斯", lng: 130.3616, lat: 46.8096, tz: 8 },
    { name: "大庆", lng: 125.1038, lat: 46.5892, tz: 8 }
  ],
  "吉林": [
    { name: "长春", lng: 125.3235, lat: 43.8170, tz: 8 },
    { name: "吉林", lng: 126.5495, lat: 43.8378, tz: 8 },
    { name: "四平", lng: 124.3504, lat: 43.1664, tz: 8 },
    { name: "延吉", lng: 129.5089, lat: 42.8912, tz: 8 }
  ],
  "辽宁": [
    { name: "沈阳", lng: 123.4314, lat: 41.8056, tz: 8 },
    { name: "大连", lng: 121.6147, lat: 38.9140, tz: 8 },
    { name: "鞍山", lng: 122.9943, lat: 41.1085, tz: 8 },
    { name: "抚顺", lng: 123.9572, lat: 41.8809, tz: 8 },
    { name: "本溪", lng: 123.7662, lat: 41.2941, tz: 8 }
  ],
  "内蒙古": [
    { name: "呼和浩特", lng: 111.7491, lat: 40.8425, tz: 8 },
    { name: "包头", lng: 109.8404, lat: 40.6574, tz: 8 },
    { name: "赤峰", lng: 118.8876, lat: 42.2578, tz: 8 },
    { name: "海拉尔", lng: 119.7658, lat: 49.2116, tz: 8 }
  ],
  "河北": [
    { name: "石家庄", lng: 114.5148, lat: 38.0423, tz: 8 },
    { name: "唐山", lng: 118.1801, lat: 39.6308, tz: 8 },
    { name: "秦皇岛", lng: 119.6005, lat: 39.9354, tz: 8 },
    { name: "邯郸", lng: 114.5391, lat: 36.6256, tz: 8 },
    { name: "保定", lng: 115.4648, lat: 38.8738, tz: 8 }
  ],
  "山西": [
    { name: "太原", lng: 112.5488, lat: 37.8705, tz: 8 },
    { name: "大同", lng: 113.3001, lat: 40.0768, tz: 8 },
    { name: "长治", lng: 113.1162, lat: 36.1954, tz: 8 },
    { name: "临汾", lng: 111.5190, lat: 36.0880, tz: 8 }
  ],
  "山东": [
    { name: "济南", lng: 117.1205, lat: 36.6519, tz: 8 },
    { name: "青岛", lng: 120.3826, lat: 36.0671, tz: 8 },
    { name: "淄博", lng: 118.0549, lat: 36.8134, tz: 8 },
    { name: "烟台", lng: 121.4479, lat: 37.4638, tz: 8 },
    { name: "潍坊", lng: 119.1617, lat: 36.7067, tz: 8 }
  ],
  "江苏": [
    { name: "南京", lng: 118.7969, lat: 32.0603, tz: 8 },
    { name: "无锡", lng: 120.3119, lat: 31.4911, tz: 8 },
    { name: "徐州", lng: 117.2841, lat: 34.2057, tz: 8 },
    { name: "常州", lng: 119.9739, lat: 31.8106, tz: 8 },
    { name: "苏州", lng: 120.5853, lat: 31.2988, tz: 8 },
    { name: "南通", lng: 120.8942, lat: 32.0162, tz: 8 }
  ],
  "安徽": [
    { name: "合肥", lng: 117.2272, lat: 31.8205, tz: 8 },
    { name: "芜湖", lng: 118.3762, lat: 31.3263, tz: 8 },
    { name: "蚌埠", lng: 117.3897, lat: 32.9162, tz: 8 },
    { name: "淮南", lng: 116.9999, lat: 32.6243, tz: 8 }
  ],
  "浙江": [
    { name: "杭州", lng: 120.1551, lat: 30.2740, tz: 8 },
    { name: "宁波", lng: 121.5503, lat: 29.8745, tz: 8 },
    { name: "温州", lng: 120.6993, lat: 27.9942, tz: 8 },
    { name: "嘉兴", lng: 120.7554, lat: 30.7461, tz: 8 },
    { name: "金华", lng: 119.6474, lat: 29.0790, tz: 8 }
  ],
  "福建": [
    { name: "福州", lng: 119.2965, lat: 26.0745, tz: 8 },
    { name: "厦门", lng: 118.0894, lat: 24.4798, tz: 8 },
    { name: "泉州", lng: 118.6756, lat: 24.8741, tz: 8 },
    { name: "漳州", lng: 117.6476, lat: 24.5130, tz: 8 }
  ],
  "江西": [
    { name: "南昌", lng: 115.8579, lat: 28.6828, tz: 8 },
    { name: "景德镇", lng: 117.2146, lat: 29.2925, tz: 8 },
    { name: "九江", lng: 115.9928, lat: 29.7120, tz: 8 },
    { name: "赣州", lng: 114.9344, lat: 25.8310, tz: 8 }
  ],
  "河南": [
    { name: "郑州", lng: 113.6253, lat: 34.7466, tz: 8 },
    { name: "开封", lng: 114.3076, lat: 34.7973, tz: 8 },
    { name: "洛阳", lng: 112.4536, lat: 34.6181, tz: 8 },
    { name: "南阳", lng: 112.5283, lat: 32.9907, tz: 8 }
  ],
  "湖北": [
    { name: "武汉", lng: 114.3053, lat: 30.5928, tz: 8 },
    { name: "黄石", lng: 115.0385, lat: 30.1996, tz: 8 },
    { name: "十堰", lng: 110.7981, lat: 32.6293, tz: 8 },
    { name: "宜昌", lng: 111.2864, lat: 30.6919, tz: 8 },
    { name: "襄阳", lng: 112.1224, lat: 32.0081, tz: 8 }
  ],
  "湖南": [
    { name: "长沙", lng: 112.9388, lat: 28.2282, tz: 8 },
    { name: "株洲", lng: 113.1338, lat: 27.8274, tz: 8 },
    { name: "湘潭", lng: 112.9440, lat: 27.8297, tz: 8 },
    { name: "衡阳", lng: 112.5718, lat: 26.8933, tz: 8 },
    { name: "岳阳", lng: 113.1289, lat: 29.3567, tz: 8 }
  ],
  "广东": [
    { name: "广州", lng: 113.2644, lat: 23.1291, tz: 8 },
    { name: "深圳", lng: 114.0579, lat: 22.5431, tz: 8 },
    { name: "珠海", lng: 113.5767, lat: 22.2707, tz: 8 },
    { name: "汕头", lng: 116.6819, lat: 23.3540, tz: 8 },
    { name: "佛山", lng: 113.1214, lat: 23.0215, tz: 8 },
    { name: "湛江", lng: 110.3593, lat: 21.2707, tz: 8 },
    { name: "东莞", lng: 113.7517, lat: 23.0206, tz: 8 },
    { name: "中山", lng: 113.3927, lat: 22.5176, tz: 8 }
  ],
  "广西": [
    { name: "南宁", lng: 108.3661, lat: 22.8172, tz: 8 },
    { name: "柳州", lng: 109.4159, lat: 24.3241, tz: 8 },
    { name: "桂林", lng: 110.2901, lat: 25.2735, tz: 8 },
    { name: "北海", lng: 109.1192, lat: 21.4812, tz: 8 }
  ],
  "海南": [
    { name: "海口", lng: 110.3492, lat: 20.0173, tz: 8 },
    { name: "三亚", lng: 109.5119, lat: 18.2528, tz: 8 }
  ],
  "四川": [
    { name: "成都", lng: 104.0665, lat: 30.5722, tz: 8 },
    { name: "自贡", lng: 104.7784, lat: 29.3392, tz: 8 },
    { name: "攀枝花", lng: 101.7186, lat: 26.5823, tz: 8 },
    { name: "泸州", lng: 105.4422, lat: 28.8718, tz: 8 },
    { name: "绵阳", lng: 104.7319, lat: 31.4606, tz: 8 }
  ],
  "贵州": [
    { name: "贵阳", lng: 106.6301, lat: 26.6476, tz: 8 },
    { name: "六盘水", lng: 104.8303, lat: 26.5926, tz: 8 },
    { name: "遵义", lng: 106.9273, lat: 27.7256, tz: 8 }
  ],
  "云南": [
    { name: "昆明", lng: 102.8328, lat: 24.8800, tz: 8 },
    { name: "曲靖", lng: 103.7961, lat: 25.4899, tz: 8 },
    { name: "大理", lng: 100.2676, lat: 25.6065, tz: 8 },
    { name: "丽江", lng: 100.2330, lat: 26.8721, tz: 8 }
  ],
  "西藏": [
    { name: "拉萨", lng: 91.1172, lat: 29.6469, tz: 8 },
    { name: "日喀则", lng: 88.8851, lat: 29.2675, tz: 8 }
  ],
  "陕西": [
    { name: "西安", lng: 108.9397, lat: 34.3415, tz: 8 },
    { name: "宝鸡", lng: 107.2375, lat: 34.3617, tz: 8 },
    { name: "咸阳", lng: 108.7051, lat: 34.3246, tz: 8 },
    { name: "延安", lng: 109.4897, lat: 36.5854, tz: 8 }
  ],
  "甘肃": [
    { name: "兰州", lng: 103.8343, lat: 36.0610, tz: 8 },
    { name: "嘉峪关", lng: 98.2891, lat: 39.7731, tz: 8 },
    { name: "天水", lng: 105.7249, lat: 34.5808, tz: 8 }
  ],
  "青海": [
    { name: "西宁", lng: 101.7782, lat: 36.6171, tz: 8 }
  ],
  "宁夏": [
    { name: "银川", lng: 106.2309, lat: 38.4871, tz: 8 }
  ],
  "新疆": [
    { name: "乌鲁木齐", lng: 87.6168, lat: 43.8255, tz: 8 },
    { name: "克拉玛依", lng: 84.8892, lat: 45.5797, tz: 8 },
    { name: "喀什", lng: 75.9897, lat: 39.4704, tz: 8 },
    { name: "伊宁", lng: 81.3241, lat: 43.9168, tz: 8 }
  ],
  "香港": [{ name: "香港", lng: 114.1694, lat: 22.3193, tz: 8 }],
  "澳门": [{ name: "澳门", lng: 113.5438, lat: 22.1987, tz: 8 }],
  "台湾": [
    { name: "台北", lng: 121.5654, lat: 25.0330, tz: 8 },
    { name: "高雄", lng: 120.3121, lat: 22.6232, tz: 8 },
    { name: "台中", lng: 120.6736, lat: 24.1477, tz: 8 }
  ]
};

export const MOON_PHASES: MoonPhaseData[] = [
  {
      num: 1,
      name: "新月相 (New Moon)",
      degreeRange: [0, 45],
      archetype: "涌现 (Emergence)",
      hemicycle: "waxing",
      hemicycleName: "蜡月期 (Life - Building Forms)",
      rudhyarCore: "Rudhyar 定义：'黑暗中的开始'。太阳的创造性冲动被植入到月球的土壤中。这是一种无意识的、本能的、甚至强迫性的活动时期。此时没有客观的意识，只有一种强烈的主观意愿，想要将自己投射到世界上。这是生命力的纯粹释放。",
      dayPhase: "☀️ 日生盘 (Solar Path - The Hero's Projection):\n作为日生人，你的太阳能量是外显的。在这个阶段，你表现为一种天真而强大的自我投射。你就像神话中的英雄，在不知不觉中踏上旅程。你的心理动力是'行动'。你可能缺乏对他人感受的敏感度（因为月亮被太阳燃烧），但这正是你为了开创新局面所需要的。你的挑战是：在盲目冲动和有效行动之间找到平衡，不要让自我的光芒灼伤了周围的人。",
      nightPhase: "🌙 夜生盘 (Lunar Path - The Dreamer's Seed):\n作为夜生人，太阳沉入地下，你的新月能量是深沉而隐秘的。你是一颗在黑暗土壤中发芽的种子。你的心理动力是'直觉感应'。你可能觉得与外部世界格格不入，生活在一个充满主观神话和梦境的内在世界里。你的力量来自于潜意识深处的涌动。你的挑战是：信任那些非理性的直觉，保护你内在脆弱的灵魂萌芽，不要被外部世界的喧嚣淹没。",
      hemicycleDescription: "🌱 蜡月期（Waxing）是'生命'（Life）的时期。这是建立有机结构和生物形式的阶段。能量是本能的、向外扩张的。在这个半周期，你是'建设者'。",
      evolutionPath: "从盲目的本能行动中浮现。你需要发现'我是谁'，并敢于在还没完全看清道路时就迈出第一步。",
      quote: "行动先于意识。存在即是去成为。——Dane Rudhyar"
  },
  {
      num: 2,
      name: "峨眉月相 (Crescent Moon)",
      degreeRange: [45, 90],
      archetype: "扩张 (Expansion)",
      hemicycle: "waxing",
      hemicycleName: "蜡月期 (Life - Building Forms)",
      rudhyarCore: "Rudhyar 定义：'为了拥抱未来，必须背叛过去'。新月的盲目冲动现在遇到了现实的第一次阻力。这是一种'动员'的能量。这是一个半觉醒的阶段，充满了与过去的幽灵（Ghosts of the Past）的斗争。",
      dayPhase: "☀️ 日生盘 (Solar Path - The Rebel Against Authority):\n你的斗争是显化的。你可能在生活中不断遇到外部的阻力——来自父亲、权威、社会传统或既定规则。你是一个积极的'奋斗者'，试图在现实世界中为自己的新身份争取空间。你的心理课题是'独立'。你可能会通过反叛、挑战权威来定义自己。挑战在于：不要为了反叛而反叛，而是为了建立新的建设性秩序。",
      nightPhase: "🌙 夜生盘 (Lunar Path - The Struggle with Instinct):\n你的斗争是内在的。阻力来自于你自己的习惯、情感依赖、安全感需求（母亲原型）或潜意识中的恐惧。你必须克服内在的惯性（Inertia）。这是一种'灵魂的动员'。你可能感到被过去的情感模式所困扰，必须在心理上切断脐带。挑战在于：依靠内在的韧性，摆脱情感勒索，从心理上'离家出走'。",
      hemicycleDescription: "🌱 蜡月期是与过去决裂、建立新形式的时期。峨眉月代表着克服惯性，动员能量。",
      evolutionPath: "动员自己走向履行。虽然'过去'的阻力很大，但您必须坚持新的冲动。不要回头。",
      quote: "为了拥抱未来，必须有勇气背叛过去的期待。——Dane Rudhyar"
  },
  {
      num: 3,
      name: "上弦月相 (First Quarter)",
      degreeRange: [90, 135],
      archetype: "行动 (Action)",
      hemicycle: "waxing",
      hemicycleName: "蜡月期 (Life - Building Forms)",
      rudhyarCore: "Rudhyar 定义：'行动中的危机' (Crisis in Action)。这是一个管理型、强力活动的时期。这是决裂的时刻，必须要建立坚实的框架（脚手架）来承载未来的理想。这是无情的清理地基，意志力（Will）是关键。",
      dayPhase: "☀️ 日生盘 (Solar Path - The Builder of Structures):\n你是一个'世俗的管理者'。危机通常表现为职业、社会地位或具体项目中的果断抉择。你有强大的意志力去构建有形的结构。你可能会显得强硬、甚至有些独裁，因为你专注于'建设'。你的心理焦点是'确立自我'。挑战在于：在强力推行意志的同时，保持对他人的觉知，确保你的'建筑'不仅坚固而且有生命力。",
      nightPhase: "🌙 夜生盘 (Lunar Path - The Architect of Psyche):\n你是一个'心灵的建筑师'。你的行动危机发生在情感和心理层面。你正在构建一个新的自我认同，这需要你坚定地拒绝那些不再滋养你灵魂的旧模式。你的意志力指向内在的整合。你可能需要在情感关系中做出艰难的'切割'。挑战在于：克服情感上的优柔寡断，勇敢地为自己的内在生活建立'骨架'。",
      hemicycleDescription: "🌱 蜡月期的关键转折点。如果你不能建立结构，能量就会消散。这是意志力的考验。",
      evolutionPath: "勇敢地切断与过去的联系，建立新的形式。不要害怕破坏旧的结构，那是为了让新生命得以成长。",
      quote: "理想如果不能落地为砖瓦和生命的温度，便毫无意义。——Dane Rudhyar"
  },
  {
      num: 4,
      name: "盈凸月相 (Gibbous Moon)",
      degreeRange: [135, 180],
      archetype: "克服 (Overcoming)",
      hemicycle: "waxing",
      hemicycleName: "蜡月期 (Life - Building Forms)",
      rudhyarCore: "Rudhyar 定义：'神圣的不满'。这是一个对完美有强烈渴望的时期。个人现在有能力评估他们所建造的东西，并致力于改进、完善。通过问'为什么'，并在智力上与伟大的思想或人物结盟，来准备启示的到来。",
      dayPhase: "☀️ 日生盘 (Solar Path - The Apprentice of Excellence):\n你通过服务于一个伟大的社会目标、技艺或理想来寻找意义。你是一个完美主义者，倾向于通过智力分析和技术精进来完善外部世界。你可能会依附于一位'导师'或'伟人'。你的心理焦点是'贡献'。挑战在于：不要让你的分析变成对他人的苛刻批评，将'不满'转化为谦逊的改进动力。",
      nightPhase: "🌙 夜生盘 (Lunar Path - The Seeker of Soul-Perfection):\n你的'克服'是指向内在的炼金术。你渴望灵魂的纯净和人格的完善。你的'为什么'是对生命存在意义的深层探究。你可能在心理或精神层面进行艰苦的自我审视。这是一种'内在的学徒期'。挑战在于：不要陷入过度的自我怀疑、内疚或焦虑，相信这种内在的压力是为了迎接即将到来的觉醒。",
      hemicycleDescription: "🌱 蜡月期的最后阶段。精益求精，为满月的启示做准备。这是从本能走向智性的过渡。",
      evolutionPath: "通过自我牺牲和技艺的磨练，学徒终将成为大师。在完善中寻找意义。",
      quote: "通过自我牺牲和技艺的磨练，学徒终将成为大师。——Dane Rudhyar"
  },
  {
      num: 5,
      name: "满月相 (Full Moon)",
      degreeRange: [180, 225],
      archetype: "履行 (Fulfillment)",
      hemicycle: "waning",
      hemicycleName: "亏月期 (Consciousness - Releasing Meaning)",
      rudhyarCore: "Rudhyar 定义：'履行与启示'。曾经是动力的'基调'现在变成了具体的'意象'。这是客观意识和清晰视觉的时刻。对立面（太阳和月亮）必须被整合。如果不能整合，就会导致分裂或'离婚'。",
      dayPhase: "☀️ 日生盘 (Solar Path - The Objective Realization):\n你的'履行'主要体现在外部的人际关系和社会互动中。你通过'看见'对方来认识自己。客观的意识在具体的伙伴关系或公众形象中达到顶峰。你能够清晰地评估社会现实。挑战在于：整合自我与他人的对立，避免将内在的阴影投射到伴侣身上。如果失败，可能会感到与世界的深刻疏离或关系破裂。",
      nightPhase: "🌙 夜生盘 (Lunar Path - The Inner Illumination):\n你的'满月'是内在的照明。这是一种深刻的直觉洞察或通灵般的清晰度。你可能在梦境、冥想或创造性想象中获得最大的启示。'履行'意味着内在阴性与阳性能量的结合（神圣婚姻）。挑战在于：将这种内在的异象（Vision）带入现实，不迷失在纯粹的主观幻象中，而是让它成为指导生活的智慧。",
      hemicycleDescription: "🌊 亏月期（Waning）是'意识'（Consciousness）的时期。不再是盲目的生物性成长，而是意义的分享和意识的觉醒。",
      evolutionPath: "将本能的动力转化为有意识的意义。超脱地看待成败，将所见转化为智慧。",
      quote: "果实的宿命就是被食用。智慧在他人的生活中重新生根。——Dane Rudhyar"
  },
  {
      num: 6,
      name: "散播月相 (Disseminating Moon)",
      degreeRange: [225, 270],
      archetype: "示范 (Demonstration)",
      hemicycle: "waning",
      hemicycleName: "亏月期 (Consciousness - Releasing Meaning)",
      rudhyarCore: "Rudhyar 定义：'种子的传播'。满月的启蒙现在必须被分享。这不再是无意识的本能行为，而是有意识的精神活动。传播者是教师、普及者，想要将自己所获得的意义传达给社会。",
      dayPhase: "☀️ 日生盘 (Solar Path - The Social Crusader):\n你是一个社会的普及者和教育者。你感到有一种强烈的使命感，要将你的理念和愿景传播给大众。你通过公开的演讲、写作或社会改革来'示范'你的真理。你可能是新思想的传播者。挑战在于：避免狂热和教条主义。不要强迫他人接受你的观点，而是通过自身的榜样和生活的质量来启发社会。",
      nightPhase: "🌙 夜生盘 (Lunar Path - The Silent Teacher):\n你是一个智慧的传承者，但方式更加隐秘和个人化。你可能通过艺术、心理咨询或深度的个人交流来分享你的领悟。你传播的是一种'氛围'或精神体验，而不仅仅是智力概念。你通过'存在'（Being）而非'宣讲'（Preaching）来教导。挑战在于：克服被误解的恐惧，找到适合你独特感悟的表达形式。",
      hemicycleDescription: "🌊 亏月期是回馈的时期。如果你拥有了光，你必须分享它，否则光会变成自我膨胀的火焰。",
      evolutionPath: "通过分享和示范来赋予您的愿景以生命。不要仅仅持有真理，要让它服务于他人。",
      quote: "为了拥抱未来，必须有勇气背叛过去的期待。——Dane Rudhyar"
  },
  {
      num: 7,
      name: "下弦月相 (Last Quarter)",
      degreeRange: [270, 315],
      archetype: "重整 (Re-orientation)",
      hemicycle: "waning",
      hemicycleName: "亏月期 (Consciousness - Releasing Meaning)",
      rudhyarCore: "Rudhyar 定义：'意识中的危机' (Crisis in Consciousness)。这是一个关于意识形态信念的时期。不再符合时代需求的旧结构必须被拆除。这种危机发生在意识层面，是对原则的坚持和对形式的讽刺。",
      dayPhase: "☀️ 日生盘 (Solar Path - The Ideological Reformer):\n你是一个意识形态的改革者。你敏锐地察觉到社会制度、法律或集体信仰中的缺陷，并感到必须要修正它们。这是一种'为了未来而管理'的能量。你可能会建立新的组织形式来体现你的原则，或者成为现有体制的严厉批评者。挑战在于：不要变得过于僵化或缺乏人情味，要明白真正的改革始于意识的转变，而非仅仅是制度的更替。",
      nightPhase: "🌙 夜生盘 (Lunar Path - The Spiritual Revolutionary):\n你经历的是深刻的信仰危机和内在价值的重估。你可能会拒绝社会普遍接受的规范，转向内在寻找更真实的法则。你是一个'内在的革命者'，通过改变自己的意识状态来影响世界。你可能显得有些孤僻，因为你在进行深刻的心理清理，为了未来的种子腾出空间。挑战在于：不陷入虚无主义，在废墟上建立精神基石。",
      hemicycleDescription: "🌊 亏月期的转折点。为了让新神诞生，必须打碎旧神的神像。这是为了未来的自由而进行的清理。",
      evolutionPath: "放下那些已经不再服务于新意识的形式。重新定位，为未来的循环建立意识形态的基础。",
      quote: "为了让新神诞生，必须先打碎旧神的神像。——Dane Rudhyar"
  },
  {
      num: 8,
      name: "残月相 (Balsamic Moon)",
      degreeRange: [315, 360],
      archetype: "释放 (Release)",
      hemicycle: "waning",
      hemicycleName: "亏月期 (Consciousness - Releasing Meaning)",
      rudhyarCore: "Rudhyar 定义：'种子状态'。这是最终的放手。它是向太阳领域的进入，不仅是结束，更是为了新周期带来的牺牲。它是预言性的，完全面向未来。个人感觉自己是社会宿命的终结者和新时代的先驱。",
      dayPhase: "☀️ 日生盘 (Solar Path - The Prophet/Martyr):\n你是一个具有社会使命感的'先知'。你可能为了一个伟大的社会理想或未来的愿景而牺牲个人的小我利益。你感到自己是历史洪流的一部分，是为了完成某种集体宿命而来。你的目光完全投向未来，虽然你身处旧时代的终结之中。挑战在于：接受这种'过渡性'的角色，不执着于个人的世俗成就，而是成为连接过去与未来的桥梁。",
      nightPhase: "🌙 夜生盘 (Lunar Path - The Mystic/Watcher):\n你是一个'守夜人'。你的牺牲是内在的，表现为小我意识的消融和与宇宙精神的融合。你可能拥有深刻的直觉，能感知到即将到来的新生命周期。你像一颗在冬天的土壤中沉睡的种子，外表静默，内在却蕴含着巨大的生命潜能。挑战在于：信任黑暗和未知的过程，允许旧的自我完全死去，以便在精神上重生。",
      hemicycleDescription: "🌊 亏月期的最后阶段。这是业力完成的时刻。你是过去与未来的链接，是未来的种子。",
      evolutionPath: "接受作为'种子'的命运。接受结束，因为那是新开始的必要条件。您不是为了现在而活，而是为了未来。",
      quote: "在黎明前的黑暗中，旧的已经死去。而你，就是那个守灯人。——Dane Rudhyar"
  }
];
